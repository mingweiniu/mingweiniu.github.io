"""OpenGL debugging utility functions/classes

This package provides various debugging mechanisms
for use particularly with more involved OpenGL
projects.
"""